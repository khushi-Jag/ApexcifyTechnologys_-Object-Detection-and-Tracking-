import time

# ---------------- ENVIRONMENT ----------------
class SearchEnvironment:
    def __init__(self, graph):
        self.graph = graph

    def get_neighbors(self, node):
        return self.graph.get(node, [])


# ======================================================
# IDDFS AGENT
# ======================================================
class IDDFSAgent:
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal
        self.nodes_expanded = 0

    def dls(self, environment, node, depth, visited):
        self.nodes_expanded += 1

        if node == self.goal:
            return [node]

        if depth <= 0:
            return None

        visited.add(node)

        for neighbor in environment.get_neighbors(node):
            if neighbor not in visited:
                path = self.dls(environment, neighbor, depth - 1, visited)
                if path:
                    return [node] + path

        return None

    def search(self, environment, max_depth=10):
        start_time = time.time()

        for depth in range(max_depth):
            visited = set()
            result = self.dls(environment, self.start, depth, visited)

            if result:
                end_time = time.time()
                return {
                    "Path": result,
                    "Depth Found": depth,
                    "Time": round(end_time - start_time, 6),
                    "Nodes Expanded": self.nodes_expanded,
                    "Memory Used": len(visited)
                }

        return None


# ======================================================
# BIDIRECTIONAL DFS AGENT
# ======================================================
class BidirectionalDFSAgent:
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal
        self.nodes_expanded = 0

    def dfs(self, environment, current, target, visited, path):
        self.nodes_expanded += 1

        visited.add(current)
        path.append(current)

        if current == target:
            return path.copy()

        for neighbor in environment.get_neighbors(current):
            if neighbor not in visited:
                result = self.dfs(environment, neighbor, target, visited, path)
                if result:
                    return result

        path.pop()
        return None

    def search(self, environment):
        start_time = time.time()

        result = self.dfs(environment, self.start, self.goal, set(), [])

        end_time = time.time()

        if result:
            return {
                "Path": result,
                "Depth Found": len(result) - 1,
                "Time": round(end_time - start_time, 6),
                "Nodes Expanded": self.nodes_expanded,
                "Memory Used": len(result)
            }

        return None


# ======================================================
# MAIN FUNCTION (TEST BOTH TREE & GRAPH)
# ======================================================
if __name__ == "__main__":

    # ---------------- TREE STRUCTURE ----------------
    tree_graph = {
        'A': ['B', 'C'],
        'B': ['D', 'E'],
        'C': ['F', 'G'],
        'D': [], 'E': [], 'F': [], 'G': []
    }

    print("\n========== TREE STRUCTURE ==========")
    env_tree = SearchEnvironment(tree_graph)

    iddfs_tree = IDDFSAgent('A', 'G')
    bidir_tree = BidirectionalDFSAgent('A', 'G')

    print("\nIDDFS Result (Tree):")
    print(iddfs_tree.search(env_tree))

    print("\nBidirectional DFS Result (Tree):")
    print(bidir_tree.search(env_tree))


    # ---------------- GRAPH STRUCTURE ----------------
    graph_structure = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'F'],
        'D': ['B'],
        'E': ['B', 'F'],
        'F': ['C', 'E']
    }

    print("\n\n========== GRAPH STRUCTURE ==========")
    env_graph = SearchEnvironment(graph_structure)

    iddfs_graph = IDDFSAgent('A', 'F')
    bidir_graph = BidirectionalDFSAgent('A', 'F')

    print("\nIDDFS Result (Graph):")
    print(iddfs_graph.search(env_graph))

    print("\nBidirectional DFS Result (Graph):")
    print(bidir_graph.search(env_graph))