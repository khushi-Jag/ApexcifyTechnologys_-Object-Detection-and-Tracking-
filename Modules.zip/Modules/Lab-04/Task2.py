import itertools

# ---------------- ENVIRONMENT ----------------
class DeliveryEnvironment:
    def __init__(self):
        # Distance Matrix
        self.distances = {
            'Depot': {'A':20, 'B':20, 'C':30, 'D':999},
            'A': {'Depot':20, 'B':10, 'C':999, 'D':25},
            'B': {'Depot':20, 'A':10, 'C':15, 'D':999},
            'C': {'Depot':30, 'A':999, 'B':15, 'D':30},
            'D': {'Depot':999, 'A':25, 'B':999, 'C':30}
        }

    def get_distance(self, from_node, to_node):
        return self.distances[from_node].get(to_node, 999)


# ---------------- UTILITY-BASED AGENT ----------------
class VehicleRoutingAgent:
    def __init__(self, vehicle_capacity=2, max_distance=100):
        self.vehicle_capacity = vehicle_capacity
        self.max_distance = max_distance

    def compute_route(self, environment, locations):

        best_route = None
        min_cost = float('inf')

        # Try all permutations (small graph so feasible)
        for perm in itertools.permutations(locations):
            route = ['Depot'] + list(perm) + ['Depot']
            total_cost = 0

            for i in range(len(route)-1):
                total_cost += environment.get_distance(route[i], route[i+1])

            if total_cost < min_cost:
                min_cost = total_cost
                best_route = route

        return best_route, min_cost

    def assign_routes(self, environment, locations, vehicles=2):

        routes = []
        chunk_size = self.vehicle_capacity

        # Divide locations among vehicles
        for i in range(0, len(locations), chunk_size):
            vehicle_locations = locations[i:i+chunk_size]

            route, cost = self.compute_route(environment, vehicle_locations)

            if cost <= self.max_distance:
                routes.append((route, cost))
            else:
                routes.append((route, "Exceeded max distance"))

        return routes


# ---------------- RUN FUNCTION ----------------
def run_agent():

    environment = DeliveryEnvironment()

    # Locations excluding depot
    locations = ['A', 'B', 'C', 'D']

    agent = VehicleRoutingAgent(vehicle_capacity=2, max_distance=150)

    routes = agent.assign_routes(environment, locations, vehicles=2)

    print("Vehicle Routing Optimization Result:\n")

    for i, (route, cost) in enumerate(routes):
        print(f"Vehicle {i+1}:")
        print("Route:", " → ".join(route))
        print("Total Distance:", cost)
        print()


run_agent()