import heapq

# ---------------- ENVIRONMENT ----------------
class WeightedGraphEnvironment:
    def __init__(self, graph, heuristic):
        self.graph = graph
        self.heuristic = heuristic

    def get_neighbors(self, node):
        return self.graph.get(node, [])

    def get_heuristic(self, node):
        return self.heuristic.get(node, 0)


# ---------------- UTILITY-BASED AGENT ----------------
class AStarAgent:
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal

    def search(self, environment):

        open_list = []
        heapq.heappush(open_list, (0, self.start))

        g_cost = {self.start: 0}
        parent = {self.start: None}

        while open_list:
            current_f, current_node = heapq.heappop(open_list)

            if current_node == self.goal:
                return self.reconstruct_path(parent)

            for neighbor, cost in environment.get_neighbors(current_node):
                tentative_g = g_cost[current_node] + cost

                if neighbor not in g_cost or tentative_g < g_cost[neighbor]:
                    g_cost[neighbor] = tentative_g
                    f_cost = tentative_g + environment.get_heuristic(neighbor)
                    heapq.heappush(open_list, (f_cost, neighbor))
                    parent[neighbor] = current_node

        return None

    def reconstruct_path(self, parent):
        node = self.goal
        path = []

        while node is not None:
            path.append(node)
            node = parent[node]

        return path[::-1]

# ---------------- RUN FUNCTION ----------------
def run_agent():

    graph = {
        'A': [('B', 1), ('C', 3)],
        'B': [('D', 1), ('E', 5)],
        'C': [('F', 2)],
        'D': [],
        'E': [('F', 1)],
        'F': []
    }

    heuristic = {
        'A': 6,
        'B': 4,
        'C': 2,
        'D': 4,
        'E': 1,
        'F': 0
    }

    environment = WeightedGraphEnvironment(graph, heuristic)
    agent = AStarAgent(start='A', goal='F')

    path = agent.search(environment)

    print("\nA* Search Result:")
    print("Optimal Path:", path)

run_agent()