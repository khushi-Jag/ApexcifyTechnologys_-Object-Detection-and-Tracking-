from collections import deque

# ---------------- ENVIRONMENT ----------------
class GraphEnvironment:
    def __init__(self, graph):
        self.graph = graph

    def get_neighbors(self, node):
        return self.graph.get(node, [])


# ---------------- GOAL-BASED AGENT ----------------
class BidirectionalSearchAgent:
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal
        self.goal_state = goal

    def search(self, environment):

        if self.start == self.goal:
            return [self.start]

        # Forward search
        forward_queue = deque([[self.start]])
        forward_visited = {self.start: [self.start]}

        # Backward search
        backward_queue = deque([[self.goal]])
        backward_visited = {self.goal: [self.goal]}

        while forward_queue and backward_queue:

            # ---- Forward Expansion ----
            forward_path = forward_queue.popleft()
            forward_node = forward_path[-1]

            for neighbor in environment.get_neighbors(forward_node):
                if neighbor not in forward_visited:
                    new_path = forward_path + [neighbor]
                    forward_visited[neighbor] = new_path
                    forward_queue.append(new_path)

                    if neighbor in backward_visited:
                        return new_path + backward_visited[neighbor][::-1][1:]

            # ---- Backward Expansion ----
            backward_path = backward_queue.popleft()
            backward_node = backward_path[-1]

            for neighbor in environment.get_neighbors(backward_node):
                if neighbor not in backward_visited:
                    new_path = backward_path + [neighbor]
                    backward_visited[neighbor] = new_path
                    backward_queue.append(new_path)

                    if neighbor in forward_visited:
                        return forward_visited[neighbor] + new_path[::-1][1:]

        return None


# ---------------- RUN FUNCTION ----------------
def run_agent():
    graph = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'F'],
        'D': ['B'],
        'E': ['B', 'F'],
        'F': ['C', 'E']
    }

    environment = GraphEnvironment(graph)
    agent = BidirectionalSearchAgent(start='A', goal='F')

    path = agent.search(environment)

    print("Bidirectional Search Result:")
    print("Path found:", path)


run_agent()