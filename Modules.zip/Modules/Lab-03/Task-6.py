import random

class CityWeatherEnvironment:
    def __init__(self):
        self.stations = {
            f"W{i}": random.choice(["Sunny", "Rainy", "Storm Alert"])
            for i in range(1, 9)
        }

    def get_percept(self, station):
        return self.stations[station]

    def display(self):
        print("\nCity Weather Report:")
        for station, status in self.stations.items():
            print(f"{station}: {status}")
        print()


class WeatherMonitoringAgent:
    def act(self, station, percept):
        if percept == "Storm Alert":
            return f"Storm warning sent from {station}"
        else:
            return f"{station} status recorded: {percept}"


def run_agent(agent, environment):
    environment.display()
    print("Collecting Weather Data...\n")

    for station in environment.stations:
        percept = environment.get_percept(station)
        action = agent.act(station, percept)
        print(f"{station}: {percept} -> {action}")


agent = WeatherMonitoringAgent()
environment = CityWeatherEnvironment()
run_agent(agent, environment)
