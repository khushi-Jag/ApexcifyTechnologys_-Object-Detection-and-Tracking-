import random

class SchoolEnvironment:
    def __init__(self):
        self.rooms = {
            f"C{i}": random.choice(["Clean", "Needs Cleaning", "Under Maintenance"])
            for i in range(1, 10)
        }

    def get_percept(self, room):
        return self.rooms[room]

    def display(self):
        print("\nSchool Building Status:")
        for room, status in self.rooms.items():
            print(f"{room}: {status}")
        print()


class CampusMaintenanceAgent:
    def act(self, room, percept):
        if percept == "Needs Cleaning":
            return f"Cleaning scheduled for {room}"
        elif percept == "Under Maintenance":
            return f"Maintenance team notified for {room}"
        else:
            return f"{room} ready for use"


def run_agent(agent, environment):
    environment.display()
    print("Inspecting Classrooms...\n")

    for room in environment.rooms:
        percept = environment.get_percept(room)
        action = agent.act(room, percept)
        print(f"{room}: {percept} -> {action}")


agent = CampusMaintenanceAgent()
environment = SchoolEnvironment()
run_agent(agent, environment)
