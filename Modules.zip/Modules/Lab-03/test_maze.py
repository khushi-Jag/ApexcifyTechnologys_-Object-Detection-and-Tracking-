# --------------------------------------------
# test_maze.py                               
# Testing DFS (Depth-Limited) and IDS
# --------------------------------------------

from search_algorithms import depth_limited_search, iterative_deepening_search

maze = [
    ['S', 0, 0, 1, 0],
    [1, 0, 1, 0, 0],
    [0, 0, 0, 0, 'G'],
    [1, 1, 0, 1, 1]
]

# Test Depth-Limited Search
print("Depth-Limited DFS Result (limit=10):")
dfs_result = depth_limited_search(maze, 10)

if dfs_result:
    print("Path found:", dfs_result)
else:
    print("No path found.")


print("\nIterative Deepening Search Result:")
ids_result = iterative_deepening_search(maze)

if ids_result:
    print("Path found:", ids_result)
else:
    print("No path found.")
