import random

class AirportEnvironment:
    def __init__(self):
        self.gates = {
            f"G{i}": random.choice(["Boarding", "Delayed", "Departed"])
            for i in range(1, 7)
        }

    def get_percept(self, gate):
        return self.gates[gate]

    def display(self):
        print("\nFlight Board:")
        for gate, status in self.gates.items():
            print(f"{gate}: {status}")
        print()


class FlightManagementAgent:
    def act(self, gate, percept):
        if percept == "Delayed":
            return f"Delay announcement at {gate}"
        elif percept == "Boarding":
            return f"Boarding announcement at {gate}"
        else:
            return f"{gate} flight departed"


def run_agent(agent, environment):
    environment.display()
    print("Monitoring Gates...\n")

    for gate in environment.gates:
        percept = environment.get_percept(gate)
        action = agent.act(gate, percept)
        print(f"{gate}: {percept} -> {action}")


agent = FlightManagementAgent()
environment = AirportEnvironment()
run_agent(agent, environment)
