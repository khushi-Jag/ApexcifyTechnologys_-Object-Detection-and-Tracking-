import random

class WarehouseEnvironment:
    def __init__(self):
        self.sections = {
            section: random.choice(["Stocked", "Low Stock", "Empty"])
            for section in ["A","B","C","D","E","F","G","H"]
        }

    def get_percept(self, section):
        return self.sections[section]

    def refill(self, section):
        self.sections[section] = "Stocked"

    def display(self):
        print("\nWarehouse Inventory:")
        for section, status in self.sections.items():
            print(f"{section}: {status}")
        print()


class InventoryControlAgent:
    def act(self, section, percept, environment):
        if percept in ["Low Stock", "Empty"]:
            environment.refill(section)
            return f"{section} refilled"
        else:
            return f"{section} fully stocked"


def run_agent(agent, environment):
    print("Initial Warehouse State:")
    environment.display()

    print("Inspecting Sections...\n")
    for section in environment.sections:
        percept = environment.get_percept(section)
        action = agent.act(section, percept, environment)
        print(f"{section}: {percept} -> {action}")

    print("\nUpdated Inventory:")
    environment.display()


agent = InventoryControlAgent()
environment = WarehouseEnvironment()
run_agent(agent, environment)
