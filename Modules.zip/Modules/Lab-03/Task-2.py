import random

class HospitalEnvironment:
    def __init__(self):
        self.rooms = {
            f"R{i}": random.choice(["Stable", "Needs Checkup", "Emergency"])
            for i in range(1, 8)
        }

    def get_percept(self, room):
        return self.rooms[room]

    def display(self):
        print("\nHospital Status:")
        for room, status in self.rooms.items():
            print(f"{room}: {status}")
        print()


class MedicalMonitoringAgent:
    def act(self, room, percept):
        if percept == "Emergency":
            return f"ALERT! Emergency response sent to {room}"
        elif percept == "Needs Checkup":
            return f"Staff notified for checkup in {room}"
        else:
            return f"{room} is stable"


def run_agent(agent, environment):
    environment.display()
    print("Scanning Patient Rooms...\n")

    for room in environment.rooms:
        percept = environment.get_percept(room)
        action = agent.act(room, percept)
        print(f"{room}: {percept} -> {action}")


agent = MedicalMonitoringAgent()
environment = HospitalEnvironment()
run_agent(agent, environment)
