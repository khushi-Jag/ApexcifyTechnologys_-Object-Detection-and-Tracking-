import random

# ---------------- ENVIRONMENT ----------------
class ParkingEnvironment:
    def __init__(self):
        self.slots = {
            f"S{i}": random.choice(["Empty", "Occupied", "Reserved"])
            for i in range(1, 11)
        }

    def get_percept(self, slot):
        return self.slots[slot]

    def update_slot(self, slot, status):
        self.slots[slot] = status

    def display(self):
        print("\nParking Lot Status:")
        for slot, status in self.slots.items():
            print(f"{slot}: {status}")
        print()


# ---------------- AGENT ----------------
class ParkingManagementAgent:
    def act(self, slot, percept, environment):
        if percept == "Empty":
            environment.update_slot(slot, "Occupied")
            return f"{slot} assigned to incoming car"
        elif percept == "Occupied":
            return f"{slot} already occupied"
        else:
            return f"{slot} reserved for special customer"


# ---------------- RUN FUNCTION ----------------
def run_agent(agent, environment):
    print("Initial State:")
    environment.display()

    print("Agent Scanning Slots...\n")
    for slot in environment.slots:
        percept = environment.get_percept(slot)
        action = agent.act(slot, percept, environment)
        print(f"{slot}: {percept} -> {action}")

    print("\nUpdated State:")
    environment.display()


agent = ParkingManagementAgent()
environment = ParkingEnvironment()
run_agent(agent, environment)
