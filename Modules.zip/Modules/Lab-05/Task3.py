import heapq
import math

# =====================================================
# ENVIRONMENT (City Map)
# =====================================================
class CityMapEnvironment:
    def __init__(self):

        # Coordinates of intersections (for heuristic)
        self.coordinates = {
            'A': (0, 0),
            'B': (2, 1),
            'C': (4, 0),
            'D': (1, 3),
            'E': (3, 3),
            'F': (5, 2),
            'G': (0, 5),
            'H': (2, 6),
            'I': (4, 5),
            'J': (6, 4),
            'K': (7, 1),
            'L': (8, 3)
        }

        # Weighted edges (distance between intersections)
        self.graph = {
            'A': [('B', 2.5), ('D', 3)],
            'B': [('A', 2.5), ('C', 2.5), ('E', 2)],
            'C': [('B', 2.5), ('F', 3)],
            'D': [('A', 3), ('E', 2), ('G', 3)],
            'E': [('B', 2), ('D', 2), ('I', 3)],
            'F': [('C', 3), ('J', 3)],
            'G': [('D', 3), ('H', 2)],
            'H': [('G', 2), ('I', 2)],
            'I': [('H', 2), ('E', 3), ('J', 2)],
            'J': [('I', 2), ('F', 3), ('L', 3)],
            'K': [('L', 2)],
            'L': [('J', 3), ('K', 2)]
        }

    def get_neighbors(self, node):
        return self.graph.get(node, [])

    # Euclidean distance heuristic
    def heuristic(self, node, goal):
        x1, y1 = self.coordinates[node]
        x2, y2 = self.coordinates[goal]
        return math.sqrt((x1 - x2)**2 + (y1 - y2)**2)


# =====================================================
# A* AGENT
# =====================================================
class AStarAgent:
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal

    def search(self, environment):

        open_list = []
        heapq.heappush(open_list, (0, self.start))

        g_cost = {self.start: 0}
        parent = {self.start: None}

        while open_list:
            current_f, current_node = heapq.heappop(open_list)

            if current_node == self.goal:
                return self.reconstruct_path(parent), g_cost[self.goal]

            for neighbor, cost in environment.get_neighbors(current_node):

                tentative_g = g_cost[current_node] + cost

                if neighbor not in g_cost or tentative_g < g_cost[neighbor]:
                    g_cost[neighbor] = tentative_g
                    f_cost = tentative_g + environment.heuristic(neighbor, self.goal)
                    heapq.heappush(open_list, (f_cost, neighbor))
                    parent[neighbor] = current_node

        return None, None

    def reconstruct_path(self, parent):
        path = []
        node = self.goal

        while node is not None:
            path.append(node)
            node = parent[node]

        return path[::-1]


# =====================================================
# MAIN FUNCTION
# =====================================================
if __name__ == "__main__":

    environment = CityMapEnvironment()

    print("Available Intersections:")
    print(", ".join(environment.graph.keys()))

    start = input("\nEnter Start Intersection: ")
    goal = input("Enter Destination Intersection: ")

    if start not in environment.graph or goal not in environment.graph:
        print("Invalid start or destination!")
    else:
        agent = AStarAgent(start, goal)
        path, cost = agent.search(environment)

        if path:
            print("\nOptimal Path Found:")
            print(" → ".join(path))
            print("Total Cost:", round(cost, 2))
        else:
            print("\nNo path found.")