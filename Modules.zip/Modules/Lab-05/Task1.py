from collections import deque

# ---------------- ENVIRONMENT ----------------
class SocialNetworkEnvironment:
    def __init__(self):
        # Graph with 10+ users
        self.graph = {
            "Alice": ["Bob", "Charlie"],
            "Bob": ["Alice", "David", "Eve"],
            "Charlie": ["Alice", "Frank"],
            "David": ["Bob", "George"],
            "Eve": ["Bob", "Hannah"],
            "Frank": ["Charlie"],
            "George": ["David"],
            "Hannah": ["Eve"],
            "Ivy": ["Jack"],          # Separate connection
            "Jack": ["Ivy"]
        }

    def get_neighbors(self, user):
        return self.graph.get(user, [])


# ---------------- BFS AGENT ----------------
class BFSAgent:
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal

    def search(self, environment):

        if self.start not in environment.graph:
            return "Start user not found in network."

        if self.goal not in environment.graph:
            return "Target user not found in network."

        visited = set()
        queue = deque([[self.start]])

        while queue:
            path = queue.popleft()
            current_user = path[-1]

            if current_user == self.goal:
                return path

            if current_user not in visited:
                visited.add(current_user)

                for neighbor in environment.get_neighbors(current_user):
                    new_path = list(path)
                    new_path.append(neighbor)
                    queue.append(new_path)

        return f"No connection found between {self.start} and {self.goal}."


# ---------------- MAIN FUNCTION ----------------
if __name__ == "__main__":

    environment = SocialNetworkEnvironment()

    print("Available Users:")
    print(", ".join(environment.graph.keys()))

    start_user = input("\nEnter Start User: ")
    target_user = input("Enter Target User: ")

    agent = BFSAgent(start_user, target_user)
    result = agent.search(environment)

    print("\nResult:")
    print(result)