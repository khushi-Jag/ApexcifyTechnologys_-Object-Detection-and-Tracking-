import heapq

# ---------------- ENVIRONMENT ----------------
class GridEnvironment:
    def __init__(self):
        # 7x7 grid
        # 0 = free cell
        # 1 = obstacle
        self.grid = [
            [0, 0, 0, 0, 1, 0, 0],
            [1, 1, 0, 0, 1, 0, 1],
            [0, 0, 0, 1, 0, 0, 0],
            [0, 1, 1, 1, 0, 1, 0],
            [0, 0, 0, 0, 0, 1, 0],
            [1, 0, 1, 1, 0, 0, 0],
            [0, 0, 0, 0, 0, 1, 0]
        ]

        self.rows = 7
        self.cols = 7

    def is_valid(self, x, y):
        return 0 <= x < self.rows and 0 <= y < self.cols and self.grid[x][y] == 0

    def display(self, path=None):
        print("\nGrid:")
        for i in range(self.rows):
            for j in range(self.cols):
                if path and (i, j) in path:
                    print("R", end=" ")  # Robot path
                elif self.grid[i][j] == 1:
                    print("X", end=" ")  # Obstacle
                else:
                    print(".", end=" ")  # Free cell
            print()
        print()


# ---------------- GBFS AGENT ----------------
class GBFSAgent:
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal

    # Manhattan Distance Heuristic
    def heuristic(self, node):
        return abs(node[0] - self.goal[0]) + abs(node[1] - self.goal[1])

    def search(self, environment):

        open_list = []
        heapq.heappush(open_list, (self.heuristic(self.start), self.start))

        visited = set()
        parent = {}
        parent[self.start] = None

        while open_list:
            _, current = heapq.heappop(open_list)

            if current == self.goal:
                return self.reconstruct_path(parent)

            visited.add(current)

            x, y = current
            neighbors = [(x+1,y), (x-1,y), (x,y+1), (x,y-1)]

            for nx, ny in neighbors:
                if environment.is_valid(nx, ny) and (nx, ny) not in visited:
                    heapq.heappush(open_list, (self.heuristic((nx, ny)), (nx, ny)))
                    if (nx, ny) not in parent:
                        parent[(nx, ny)] = current

        return None

    def reconstruct_path(self, parent):
        path = []
        node = self.goal

        while node:
            path.append(node)
            node = parent[node]

        return path[::-1]


# ---------------- MAIN FUNCTION ----------------
if __name__ == "__main__":

    environment = GridEnvironment()

    start = (0, 0)
    goal = (6, 6)

    agent = GBFSAgent(start, goal)

    print("Start:", start)
    print("Goal:", goal)

    path = agent.search(environment)

    if path:
        print("\nPath Found:", path)
        print("Path Length:", len(path))
        environment.display(path)
    else:
        print("\nNo path found!")