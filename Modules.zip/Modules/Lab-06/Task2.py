import random

GRID = 10
SENSOR_RANGE = 2
NUM_SENSORS = 4

def coverage(sensors):
    covered=set()
    for sx,sy in sensors:
        for x in range(GRID):
            for y in range(GRID):
                if abs(x-sx)+abs(y-sy)<=SENSOR_RANGE:
                    covered.add((x,y))

    return len(covered)/(GRID*GRID)*100

def neighbor(sensors):
    new = sensors[:]
    i=random.randint(0,len(sensors)-1)
    new[i]=(random.randint(0,GRID-1),random.randint(0,GRID-1))
    return new

def hill_climb(sensors):
    current=sensors
    current_score=coverage(current)

    while True:
        next_state=neighbor(current)
        next_score=coverage(next_state)

        if next_score>current_score:
            current=next_state
            current_score=next_score
        else:
            break

    return current,current_score

sensors=[(random.randint(0,9),random.randint(0,9)) for _ in range(NUM_SENSORS)]

best,score=hill_climb(sensors)

print("Optimized Sensors:",best)
print("Coverage %:",round(score,2))