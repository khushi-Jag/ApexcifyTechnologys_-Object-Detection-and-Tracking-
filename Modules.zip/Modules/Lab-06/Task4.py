users = [
    {"name":"U1","demand":20,"priority":3},
    {"name":"U2","demand":30,"priority":2},
    {"name":"U3","demand":10,"priority":5},
    {"name":"U4","demand":25,"priority":1},
]

total_bandwidth = 50
beam_width = 3

def score(state):
    value=0
    for u,b in state.items():
        priority = next(x["priority"] for x in users if x["name"]==u)
        value += b*priority

    return value

states=[{}]

for user in users:
    candidates=[]
    for s in states:
        for alloc in [0,user["demand"]]:
            new=dict(s)
            new[user["name"]]=alloc
            if sum(new.values())<=total_bandwidth:
                candidates.append(new)

    candidates=sorted(candidates,key=score,reverse=True)
    states=candidates[:beam_width]

best=max(states,key=score)

print("Optimal Allocation:",best)
print("Performance Score:",score(best))


