import heapq

#Grid size
GRID_SIZE = 7

#Obstacles (unsafe areas)
obstacles = [(2,2),(2,3),(3,2),(4,4)]

goal = (6,6)

#Manhattan distance
def heuristic(pos):
    return abs(pos[0]-goal[0]) + abs(pos[1]-goal[1])

#Safety score (avoid obstacles)
def safety_penalty(pos):
    if pos in obstacles:
        return 100
    return 0

def beam_search(start, beam_width, depth_limit):
    paths = [[start]]
    for depth in range(depth_limit):
        candidates = []
        for path in paths:
            x,y = path[-1]
            moves = [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]
            for nx,ny in moves:
                if 0<=nx<GRID_SIZE and 0<=ny<GRID_SIZE:
                    new_path = path + [(nx,ny)]
                    score = heuristic((nx,ny)) + safety_penalty((nx,ny))
                    candidates.append((score,new_path))

        candidates.sort(key=lambda x:x[0])
        paths = [p for _,p in candidates[:beam_width]]

    best = min(paths, key=lambda p: heuristic(p[-1]))
    return best, heuristic(best[-1])

start = (0,0)

beam_width = int(input("Beam width: "))
depth = int(input("Depth limit: "))

path,score = beam_search(start,beam_width,depth)

print("Best Path:",path)
print("Evaluation Score:",score)