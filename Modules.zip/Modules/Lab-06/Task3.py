import random

tasks = {
    "T1":4,
    "T2":3,
    "T3":5,
    "T4":2,
    "T5":6
}

POP_SIZE=6
GEN=50
MUT_RATE=0.1

def fitness(schedule):
    time=0
    for t in schedule:
        time+=tasks[t]

    return time

def create_population():
    pop=[]
    for _ in range(POP_SIZE):
        individual=list(tasks.keys())
        random.shuffle(individual)
        pop.append(individual)

    return pop

def crossover(p1,p2):
    cut=random.randint(1,len(p1)-2)
    child=p1[:cut]
    for gene in p2:
        if gene not in child:
            child.append(gene)

    return child

def mutate(ind):
    if random.random()<MUT_RATE:
        i,j=random.sample(range(len(ind)),2)
        ind[i],ind[j]=ind[j],ind[i]

    return ind

pop=create_population()
for _ in range(GEN):
    pop=sorted(pop,key=fitness)
    new_pop=pop[:2]

    while len(new_pop)<POP_SIZE:
        p1,p2=random.sample(pop[:4],2)
        child=crossover(p1,p2)
        child=mutate(child)
        new_pop.append(child)

    pop=new_pop

best=sorted(pop,key=fitness)[0]

print("Best Schedule:",best)
print("Total Production Time:",fitness(best))