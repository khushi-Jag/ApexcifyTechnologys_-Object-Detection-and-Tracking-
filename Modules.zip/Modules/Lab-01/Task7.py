class BankAccount:
    def __init__(self, name, acc_no, balance):
        self.name = name
        self.acc_no = acc_no
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount
        print("Amount deposited successfully")

    def withdraw(self, amount):
        if amount > self.balance:
            print("Insufficient balance")
        else:
            self.balance -= amount
            print("Withdrawal successful")

    def display(self):
        print("Name:", self.name)
        print("Account Number:", self.acc_no)
        print("Balance:", self.balance)

account = BankAccount("Ali", 12345, 5000)
account.deposit(2000)
account.withdraw(3000)
account.display()