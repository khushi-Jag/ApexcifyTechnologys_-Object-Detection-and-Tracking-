def find_largest(lst):
    maximum = float('-inf')
    for item in lst:
        if isinstance(item, list):
            maximum = max(maximum, find_largest(item))
        else:
            maximum = max(maximum, item)
    return maximum

numbers = [3, [5, 7, [2, 9]], [1, [10, 4]]]
print(find_largest(numbers))