import random

def guessing_game():
    number = random.randint(1, 100)
    attempts = 0

    while True:
        guess = int(input("Guess the number (1-100): "))
        attempts += 1

        if guess > number:
            print("Too high!")
        elif guess < number:
            print("Too low!")
        else:
            print("Correct!")
            print("Attempts:", attempts)
            break

    play_again = input("Play again? (yes/no): ")
    if play_again.lower() == "yes":
        guessing_game()

guessing_game()