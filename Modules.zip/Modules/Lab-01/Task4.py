def word_count(sentence):
    words = sentence.lower().split()
    count = {}
    for word in words:
        count[word] = count.get(word, 0) + 1
    return count

print(word_count("AI is fun and AI is powerful"))