class SecuritySensor:
    def alert(self):
        print("Security alert triggered")


class MotionSensor(SecuritySensor):
    def alert(self):
        print("Motion detected!")


class FireSensor(SecuritySensor):
    def alert(self):
        print("Fire alarm triggered!")


class GasSensor(SecuritySensor):
    def alert(self):
        print("Gas leak detected!")


sensors = [
    MotionSensor(),
    FireSensor(),
    GasSensor()
]

for sensor in sensors:
    sensor.alert()