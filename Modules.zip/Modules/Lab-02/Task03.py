class SecurityAgent:
    def __init__(self, agent_id, name):
        self.agent_id = agent_id
        self.name = name

    def show_info(self):
        print("Agent ID:", self.agent_id)
        print("Name:", self.name)


class AIAgent(SecurityAgent):
    def __init__(self, agent_id, name, model_version):
        super().__init__(agent_id, name)
        self.model_version = model_version

    def show_info(self):
        super().show_info()
        print("Model Version:", self.model_version)


class AdvancedAIAgent(AIAgent):
    def __init__(self, agent_id, name, model_version):
        super().__init__(agent_id, name, model_version)

    def show_info(self):
        super().show_info()
        print("Agent Level: Advanced AI Agent")

    def analyze_threat(self):
        print(self.name, "is analyzing threats using model", self.model_version)


agent = AdvancedAIAgent(101, "Gotam_AI", "v3.2")

agent.show_info()
agent.analyze_threat()