class User:
    def __init__(self, username, password):
        self.__username = username
        self.__password = password

    def set_password(self, new_pass):
        self.__password = new_pass
        print("Password updated successfully")

    def verify_password(self, input_pass):
        return self.__password == input_pass

    def get_username(self):
        return self.__username


class AdminUser(User):
    def reset_password(self, user, new_pass):
        user.set_password(new_pass)
        print("Admin reset the user's password")


class GuestUser(User):
    def set_password(self, new_pass):
        print("Guest users cannot change passwords")


admin = AdminUser("admin", "admin123")
guest = GuestUser("guest", "guest123")
user = User("gotam", "pass123")

print("Verify user password:", user.verify_password("pass123"))

admin.reset_password(user, "newpass")

guest.set_password("guestpass")

print("Guest can view username:", guest.get_username())