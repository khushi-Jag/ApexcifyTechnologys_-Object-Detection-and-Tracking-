class IntrusionDetector:
    def detect_intrusion(self):
        print("Detecting intrusion in the system")


class NetworkDetector(IntrusionDetector):
    def detect_intrusion(self):
        print("Monitoring network traffic for suspicious activity")


class HostDetector(IntrusionDetector):
    def detect_intrusion(self):
        print("Analyzing host logs for unauthorized access")


class ApplicationDetector(IntrusionDetector):
    def detect_intrusion(self):
        print("Inspecting application behavior for security threats")


detectors = [
    NetworkDetector(),
    HostDetector(),
    ApplicationDetector()
]

for detector in detectors:
    detector.detect_intrusion()