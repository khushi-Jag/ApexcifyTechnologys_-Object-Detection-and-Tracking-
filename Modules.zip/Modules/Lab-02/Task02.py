class LogAnalyzer:
    def __init__(self):
        self.__logs = []

    def add_log(self, entry):
        if isinstance(entry, str):
            self.__logs.append(entry)
        else:
            print("Invalid log entry")

    def get_logs(self):
        return self.__logs.copy()

    def analyze_logs(self):
        suspicious_words = ["error", "attack", "unauthorized"]
        count = 0

        for log in self.__logs:
            log_lower = log.lower()
            for word in suspicious_words:
                if word in log_lower:
                    count += 1
                    break

        print("Suspicious log entries:", count)


analyzer = LogAnalyzer()

analyzer.add_log("User logged in successfully")
analyzer.add_log("Unauthorized access detected")
analyzer.add_log("System error occurred")
analyzer.add_log(123)

analyzer.analyze_logs()